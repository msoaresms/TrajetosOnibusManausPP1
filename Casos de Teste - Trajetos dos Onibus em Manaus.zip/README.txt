Arquivo zip gerado em: 09/11/2017 17:03:00 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trajetos dos Ônibus em Manaus